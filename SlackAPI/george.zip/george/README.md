# bot.py

This is a slack bot named *george*. george gets jokes from the dad joke subreddit using the [reddit API](https://www.reddit.com/dev/api/). If you ask george to tell you joke, he'll either respond with a dad joke or error message.

To interact: `@george tell me a joke`